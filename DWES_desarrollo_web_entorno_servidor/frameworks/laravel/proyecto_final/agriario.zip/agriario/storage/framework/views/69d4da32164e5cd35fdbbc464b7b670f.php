<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="text-center mb-4">
            <h2 class="fw-semibold text-gray-800 dark:text-gray-200">Perfil</h2>
        </div>

        <h1 class="text-center text-gray-800 dark:text-gray-200">¡Hola! Esta es la página de perfil</h1>
        <!-- Línea temporalmente agregada -->

        <div class="row justify-content-center mt-4">
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm p-4 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border-0">
                    <div class="card-body">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card shadow-sm p-4 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border-0">
                    <div class="card-body">
                        <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card shadow-sm p-4 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border-0">
                    <div class="card-body">
                        <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/git/DWES-Laravel/proyectos/AgriArio/agriario/resources/views/profile/edit.blade.php ENDPATH**/ ?>