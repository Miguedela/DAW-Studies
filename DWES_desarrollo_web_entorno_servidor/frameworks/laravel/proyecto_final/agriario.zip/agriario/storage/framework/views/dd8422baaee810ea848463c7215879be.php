<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4 text-center text-white fw-bolder fs-1">Lista de Tractores</h1>

        <div class="mb-4 text-center">
            <a href="<?php echo e(route('tractores.create')); ?>" class="btn btn-success">Crear Nuevo Tractor</a>
        </div>

        <?php if($tractores->isEmpty()): ?>
            <p class="text-center text-gray-300">No hay tractores disponibles.</p>
        <?php else: ?>
            <div class="d-flex flex-column pb-4">
                <div class=" row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                    <?php $__currentLoopData = $tractores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card h-100 shadow-sm bg-gray-800 text-white border-gray-700">
                                <img src="<?php echo e(asset($tractor->imagen)); ?>" class="card-img-top"
                                    alt="Imagen de <?php echo e($tractor->nombre); ?>">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($tractor->nombre); ?></h5>
                                    <p class="card-text"><strong>Año:</strong> <?php echo e($tractor->anio_fabricacion); ?></p>
                                    <p class="card-text"><strong>Precio:</strong> $<?php echo e(number_format($tractor->precio_mercado, 2)); ?>

                                    </p>
                                    <p class="card-text"><strong>Potencia:</strong> <?php echo e($tractor->potencia); ?> HP</p>
                                    <p class="card-text"><?php echo e(Str::limit($tractor->descripcion, 100, '...')); ?></p>
                                </div>
                                <div class="card-footer text-center bg-gray-700 border-top-gray-600">
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#tractorModal<?php echo e($tractor->id); ?>">
                                        Ver más
                                    </button>

                                    <a href="<?php echo e(route('tractores.edit', $tractor->id)); ?>" class="btn btn-warning">Editar</a>

                                    <form action="<?php echo e(route('tractores.destroy', $tractor->id)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="tractorModal<?php echo e($tractor->id); ?>" tabindex="-1"
                            aria-labelledby="tractorModalLabel<?php echo e($tractor->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content bg-gray-800 text-white">
                                    <div class="modal-header bg-gray-700 border-bottom-gray-600">
                                        <h5 class="modal-title" id="tractorModalLabel<?php echo e($tractor->id); ?>"><?php echo e($tractor->nombre); ?></h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <img src="<?php echo e(asset($tractor->imagen)); ?>" class="img-fluid mb-3"
                                            alt="Imagen de <?php echo e($tractor->nombre); ?>">
                                        <p><strong>Año de fabricación:</strong> <?php echo e($tractor->anio_fabricacion); ?></p>
                                        <p><strong>Precio:</strong> $<?php echo e(number_format($tractor->precio_mercado, 2)); ?></p>
                                        <p><strong>Potencia:</strong> <?php echo e($tractor->potencia); ?> HP</p>
                                        <p><strong>Descripción:</strong> <?php echo e($tractor->descripcion); ?></p>
                                    </div>
                                    <div class="modal-footer bg-gray-700 border-top-gray-600">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($tractores->links()); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/git/DWES-Laravel/proyectos/AgriArio/agriario/resources/views/tractores/index.blade.php ENDPATH**/ ?>